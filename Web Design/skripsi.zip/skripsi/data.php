<?php
    include("kon/koneksi.php");
    $sql = mysqli_query($koneksi, "SELECT * FROM `tbl_hidrogen` ORDER BY `tbl_hidrogen`.`id_hidrogen` ASC");
    $result = array();
    
    while ($row = mysqli_fetch_assoc($sql)) {
        $data[] = $row;
    }

    echo json_encode(array("result" => $data));
?>