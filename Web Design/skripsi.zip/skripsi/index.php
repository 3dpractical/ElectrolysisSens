<?php  
@session_start();
require_once "kon/koneksi.php";
if (isset($_POST['form']) &&  $_POST['form'] == "reset") {
  $qreset = $koneksi->query("truncate `tbl_hidrogen`") or die(mysqli_error($koneksi));
  if ($qreset) {
   echo "<script>alert('update data berhasil');window.location='index.php';</script> ";
   }else {
  echo "<script>alert('update data gagal');window.location='index.php';</script> " ;   
    }
  }

?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Electrolysis</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="asset/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="asset/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="asset/css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="asset/css/pop.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="asset/css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="asset/css/custom.css">
    <link rel="stylesheet" href="asset/css/jquery.dataTables.min.css">
    <style type="text/css">
    	.theaddd{
    		text-align: center;padding: 0;background: #007bff;color: white;
    	}
    </style>
    </head>
    <body style="background-color: #eef5f9">
	<div class="container-fluid" style="padding:0px">
		<br>
	  <div class="row page-header">
	  	<div class="col-lg-4"></div>
	    <div class="col-lg-4">
          <div class="container-fluid">
            <h1 class="no-margin-bottom" style="text-align: center;font-size: 32px">Electrolysis <br>Web Monitoring</h1>
          </div>	    	
	    </div>
	    <div class="col-lg-4"></div>
	  </div>
	  <div class="row" style="margin-top: 50px;margin-bottom: 50px;">
	  	<div class="col-lg-3"></div>
	    <div class="col-lg-2">
            <section class="dashboard-counts" style="margin: 0px;padding: 0px">
              <div class="container-fluid" style="margin: 0px;padding: 0px">
                <div class="row bg-white has-shadow" style="margin: 0px;padding: 5px" >
                   <!-- Item -->
                    <div class="item d-flex align-items-center" style="margin:auto;">
                      <div class="title" style='text-align: center'><span>pH</span>
                        <div class="">
                        <?php 
                        $querya=mysqli_query($koneksi,"SELECT * FROM `tbl_hidrogen` ORDER BY `tbl_hidrogen`.`id_hidrogen` DESC LIMIT 1");
                        $hasila=mysqli_fetch_assoc($querya);
                        if($hasila['ph']>0){
                          echo "<div class='number' style='text-align: center'><strong>".$hasila['ph']."</strong></div>";
                        }else{
                          echo "<div class='number' style='text-align: center'><strong>0</strong></div>";
                        }
                        ?> 
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>	    	
	    </div>
	    <div class="col-lg-2">
            <section class="dashboard-counts" style="margin: 0px;padding: 0px">
              <div class="container-fluid" style="margin: 0px;padding: 0px">
                <div class="row bg-white has-shadow" style="margin: 0px;padding: 5px" >
                   <!-- Item -->
                    <div class="item d-flex align-items-center" style="margin:auto;">
                      <div class="title" style='text-align: center'><span>Hydrogen(ppm)</span>
                        <div class="">
                        <?php 
                        $querya=mysqli_query($koneksi,"SELECT * FROM `tbl_hidrogen` ORDER BY `tbl_hidrogen`.`id_hidrogen` DESC LIMIT 1");
                        $hasila=mysqli_fetch_assoc($querya);
                        if($hasila['ph']>0){
                          echo "<div class='number' style='text-align: center'><strong>".$hasila['h2']."</strong></div>";
                        }else{
                          echo "<div class='number' style='text-align: center'><strong>0</strong></div>";
                        }
                        ?> 
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>	    	
	    </div>
	    <div class="col-lg-2">
            <section class="dashboard-counts" style="margin: 0px;padding: 0px">
              <div class="container-fluid" style="margin: 0px;padding: 0px">
                <div class="row bg-white has-shadow" style="margin: 0px;padding: 5px" >
                   <!-- Item -->
                    <div class="item d-flex align-items-center" style="margin:auto;">
                      <div class="title" style='text-align: center'><span>Current(mA)</span>
                        <div class="">
                        <?php 
                        $querya=mysqli_query($koneksi,"SELECT * FROM `tbl_hidrogen` ORDER BY `tbl_hidrogen`.`id_hidrogen` DESC LIMIT 1");
                        $hasila=mysqli_fetch_assoc($querya);
                        if($hasila['ph']>0){
                          echo "<div class='number'style='text-align: center'><strong>".$hasila['arus']."</strong></div>";
                        }else{
                          echo "<div class='number' style='text-align: center'><strong>0</strong></div>";
                        }
                        ?> 
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>	    	
	    </div>
		<div class="col-lg-3"></div>	    	    
	  </div>
	  <div class="row page-header">
	  	<div class="col-lg-3"></div>
	    <div class="col-lg-6">
	    	<form method="post" action="" enctype="multipart/form-data">
	    		<input type="hidden" name="form" value="reset" readonly>
	    		<button type="submit" class="btn btn-danger " name="reset" style="width: 20%;float: right;margin-bottom: 10px">Reset Data</button>
	    	</form>
	    	<table align="center" border=1 style="font-size: 25px;width: 100%;">
    		<tr>
        		<th width="60px" class="theaddd">No</th>
        		<th width="170px" class="theaddd">Hydrogen</th>
        		<th width="90px" class="theaddd">pH</th>
        		<th width="120px" class="theaddd">Current</th>
        		<th width="auto" class="theaddd">Time</th>
    		</tr>
    		<tr>
    			<th colspan="5" style="margin: 0;padding: 0;">
			        <table align="center" border=1 id="realtime" class="table table-striped ">
			        	<tbody>
			        	<tr>
			        	</tr>
			        	</tbody>
			        </table>    				
    			</th>
    		</tr>
    	</table>
	    </div>
	    <div class="col-lg-3"></div>
	  </div>
	  <div class="row fixed-bottom" style="margin-bottom: 5px">
	  	<div class="col-lg-4"></div>
	    <div class="col-lg-4">
	    	<a target="_blank" href="save.php" class="btn btn-primary " style="width: 100%">Download XLS</a></div>
	    <div class="col-lg-4"></div>
	  </div>	  
	</div>



    <!-- Javascript files-->
    <script src="asset/js/jquery-3.2.1.min.js"></script>   
    <script src="asset/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="asset/vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script type="text/javascript" src="asset/vendor/chart/Chart.min.js"></script>
    <script src="asset/vendor/jquery-validation/jquery.validate.min.js"></script>
    <script type="text/javascript" src="asset/js/clock-1.1.0.min.js"></script>
    <script type="text/javascript" src="asset/js/jquery.dataTables.min.js"></script>
    <!--- <script src="asset/js/charts-home.js"></script> -->
    <!-- Main File-->
    <script src="asset/js/front.js"></script>
        <script type="text/javascript">
	$(document).ready(function() {
    selesai();
});
 
function selesai() {
	setTimeout(function() {
		update();
		selesai();
	}, 500);
}
 
function update() {
	$.getJSON("data.php", function(data) {
		$("#realtime").empty();
		var no = 1;
		$.each(data.result, function() {
			$("#realtime").append("<tr><th width='60px' style='text-align: center'>"+(no++)+"</th><th width='170px' style='text-align: center'>"+this['h2']+"ppm</th><th width='90px' style='text-align: center'>"+this['ph']+"</th><th width='120px' style='text-align: center'>"+this['arus']+"mA</th><th style='text-align: center'>"+this['tanggal']+"</th></tr>");
			//$('#realtime').append(["<td class='id'>"+this['tanggal']+"</td>"]);

		});
	});
}
</script>
    </body>

</html>
