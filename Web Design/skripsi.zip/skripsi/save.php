<!DOCTYPE html>
<html>
<head>
	<title>Electrolysis</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data Electrolysis.xls");
	?>
 
	<center>
		<h1>Export Data Electrolysis</h1>
	</center>
 
	<table border="1" align="center">
		<tr>
			<th>No</th>
			<th>Hydrogen(ppm)</th>
			<th>ph</th>
			<th>Current(mA)</th>
			<th>Time</th>
		</tr>
		<?php 
		// koneksi database
		include("kon/koneksi.php");
 
		// menampilkan data pegawai
		$data = mysqli_query($koneksi,"SELECT * FROM `tbl_hidrogen` ORDER BY `tbl_hidrogen`.`id_hidrogen` ASC");
		$no = 1;
		while($d = mysqli_fetch_array($data)){
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $d['h2']; ?></td>
			<td><?php echo $d['ph']; ?></td>
			<td><?php echo $d['arus']; ?></td>
			<td><?php echo $d['tanggal']; ?></td>
		</tr>
		<?php 
		}
		?>
	</table>
</body>
</html>