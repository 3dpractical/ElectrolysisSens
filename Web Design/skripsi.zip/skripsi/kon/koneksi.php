<?php
error_reporting(E_ALL^(E_NOTICE|E_WARNING));
if(!isset($_SESSION)){
	session_start();
	ob_start();
	//header( "HTTP/* 404 NOT FOUND" );
} 
$koneksi=mysqli_connect("localhost","u1012525_airpurifier","u1012525_airpurifier","u1012525_ electrolysys");
//$koneksi=mysqli_connect("localhost","id8592240_epemilu321","crew321123","id8592240_epemilu");
$root_base = "hidrogen/";
$img_loc=$root_base."img/";
setlocale(LC_ALL,'id_ID');
function tgl_indo($tanggal){
  $bulan = array (
    1 =>   'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember'
  );
  $pecahkan = explode('-', $tanggal);
  
  // variabel pecahkan 0 = tanggal
  // variabel pecahkan 1 = bulan
  // variabel pecahkan 2 = tahun
 
  return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}
?>