<?php  

@session_start();
require_once "kon/koneksi.php"; 
ob_start();

//get data
$h2 = $_GET["h2"];
$ph = $_GET["ph"];
$arus = $_GET["arus"];
// Create connection
$conn = $koneksi;
// Check connection
if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
}
if ($h2==nul || $ph==null || $arus==null ) {
	echo "0";
}else{
	$querry = $koneksi->query( "INSERT INTO `tbl_hidrogen` (`id_hidrogen`, `h2`, `ph`, `arus`, `tanggal`) VALUES (NULL, '$h2', '$ph', '$arus', current_timestamp());" )or die( mysqli_error( $koneksi ) ); 
	 echo "1" ; 
	 
}
mysqli_close($conn);
?>